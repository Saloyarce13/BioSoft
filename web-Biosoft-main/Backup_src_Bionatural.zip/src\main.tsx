
  import { createRoot } from "react-dom/client";
  import App from "./App.tsx";
  import "./index.css";
  import { SystemConfigProvider } from "./shared/contexts/SystemConfigContext.tsx";

  createRoot(document.getElementById("root")!).render(
    <SystemConfigProvider>
      <App />
    </SystemConfigProvider>
  );
  