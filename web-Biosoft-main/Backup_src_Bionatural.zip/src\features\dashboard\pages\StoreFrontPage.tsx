import React, { useState } from 'react';
import { Leaf, Heart, ShoppingCart, Search, Repeat, Package } from 'lucide-react';
import { toast } from 'sonner';
import { ProductDetailModal } from '../../products/pages/ProductDetailPage';

export interface UnifiedProduct {
  id: string | number;
  name: string;
  description: string;
  price: number;
  image?: string;
  category: string;
  stock: number;
  status?: 'Activo' | 'Inactivo' | 'Descontinuado';
  sku?: string;
  supplier?: string;
  technicalSheet?: string;
  cost?: number;
  margin?: number;
  weight?: number;
  barcode?: string;
  minStock?: number;
  isActive?: boolean;
  createdDate?: string;
  updatedDate?: string;
  totalSales?: number;
  lastSaleDate?: string | null;
}

export function StoreBanner({ products, userName, loading }: { products: any[]; userName?: string; loading: boolean }) {
  const bgImages = products.filter(p => p.image).map(p => p.image as string);
  const [bgIdx, setBgIdx] = React.useState(0);

  React.useEffect(() => {
    if (bgImages.length === 0) return;
    const t = setInterval(() => setBgIdx(c => (c + 1) % bgImages.length), 4000);
    return () => clearInterval(t);
  }, [bgImages.length]);

  const bgSrc = bgImages.length > 0 ? bgImages[bgIdx % bgImages.length] : '';

  return (
    <div style={{ position: 'relative', borderRadius: 20, overflow: 'hidden', height: 180, marginBottom: 28 }}>
      {bgSrc && (
        <img key={bgSrc} src={bgSrc} alt=""
          style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' }}
          onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
      )}
      <div style={{ position: 'absolute', inset: 0, background: bgSrc ? 'linear-gradient(135deg, rgba(0,0,0,0.72) 0%, rgba(0,0,0,0.4) 55%, rgba(58,125,68,0.25) 100%)' : 'linear-gradient(135deg, #1B4332 0%, #2D6A4F 50%, #3A7D44 100%)' }} />
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '0 36px', zIndex: 2 }}>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, backgroundColor: 'rgba(129,199,132,0.2)', border: '1px solid rgba(129,199,132,0.4)', borderRadius: 99, padding: '4px 12px', marginBottom: 10, width: 'fit-content' }}>
          <Leaf style={{ width: 11, height: 11, color: '#81C784' }} />
          <span style={{ fontSize: 10, color: '#81C784', fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase' as const }}>100% Natural</span>
        </div>
        <h2 style={{ fontSize: 24, fontWeight: 800, color: 'white', letterSpacing: '-0.02em', lineHeight: 1.2, marginBottom: 6, textShadow: '0 2px 12px rgba(0,0,0,0.3)' }}>
          {userName ? `Hola, ${userName.split(' ')[0]} 👋` : 'Bienvenido a tu tienda'}
        </h2>
        <p style={{ fontSize: 13, color: 'rgba(255,255,255,0.75)', lineHeight: 1.5 }}>
          {loading ? 'Cargando...' : `${products.length} productos naturales disponibles`}
        </p>
      </div>
      {bgImages.length > 1 && (
        <div style={{ position: 'absolute', bottom: 12, right: 20, display: 'flex', gap: 5, zIndex: 3 }}>
          {bgImages.slice(0, 8).map((_, i) => (
            <button key={i} onClick={() => setBgIdx(i)}
              style={{ width: i === bgIdx ? 20 : 6, height: 6, borderRadius: 99, backgroundColor: i === bgIdx ? 'white' : 'rgba(255,255,255,0.4)', border: 'none', cursor: 'pointer', transition: 'all 0.3s', padding: 0 }} />
          ))}
        </div>
      )}
    </div>
  );
}

export function ClientStorefront({ onAddToCart, isFavorite, toggleFavorite, userName }: {
  onAddToCart: (product: UnifiedProduct) => void;
  isFavorite: (id: string | number) => boolean;
  toggleFavorite: (product: any) => void;
  userName?: string;
}) {
  const [products, setProducts] = useState<UnifiedProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [selectedProduct, setSelectedProduct] = useState<UnifiedProduct | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);

  const fetchProducts = React.useCallback(async () => {
    try {
      const { getProducts } = await import('../../../lib/api');
      const res = await getProducts();
      if (res.success) {
        setProducts(res.data.filter((p: any) => p.isActive && p.stock > 0).map((p: any) => ({
          id: String(p.id), name: p.name, description: p.description || '',
          price: Number(p.price), image: p.image || '', category: p.category?.name || '',
          stock: p.stock || 0, status: 'Activo' as const, isActive: true,
          minStock: p.minStock || 5, sku: p.sku || '', supplier: p.provider?.name || '',
          createdDate: '', updatedDate: '', totalSales: 0, lastSaleDate: null,
          cost: Number(p.cost) || 0, margin: 0,
        })));
      }
    } catch { } finally { setLoading(false); }
  }, []);

  React.useEffect(() => { fetchProducts(); }, [fetchProducts]);
  React.useEffect(() => {
    const t = setInterval(fetchProducts, 30_000);
    return () => clearInterval(t);
  }, [fetchProducts]);

  const categories = ['all', ...Array.from(new Set(products.map(p => p.category)))];
  const filtered = products.filter(p =>
    (p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.description.toLowerCase().includes(searchTerm.toLowerCase())) &&
    (categoryFilter === 'all' || p.category === categoryFilter)
  );
  const fmt = (n: number) => new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(n);

  const getCategoryStyle = (cat: string) => {
    const map: Record<string, { bg: string; color: string; light: string }> = {
      'Tés e Infusiones':     { bg: '#FEF3C7', color: '#D97706', light: '#FFFBEB' },
      'Aceites Esenciales':   { bg: '#E0F2FE', color: '#0284C7', light: '#F0F9FF' },
      'Hierbas Medicinales':  { bg: '#DCFCE7', color: '#16A34A', light: '#F0FDF4' },
      'Suplementos':          { bg: '#F3E8FF', color: '#9333EA', light: '#FAF5FF' },
      'Cosméticos Naturales': { bg: '#FCE7F3', color: '#DB2777', light: '#FDF2F8' },
      'Alimentos Orgánicos':  { bg: '#FEF9C3', color: '#CA8A04', light: '#FEFCE8' },
      'Alimentos Dieteticos': { bg: '#FEF9C3', color: '#CA8A04', light: '#FEFCE8' },
      'Aromerapia':           { bg: '#E0F2FE', color: '#0369A1', light: '#F0F9FF' },
      'Medicina Alternativa': { bg: '#F0FDF4', color: '#15803D', light: '#F0FDF4' },
    };
    return map[cat] || { bg: '#F0F4EF', color: '#3A7D44', light: '#F7FAF7' };
  };

  return (
    <div style={{ maxWidth: 1280, margin: '0 auto', fontFamily: 'Inter, system-ui, sans-serif' }}>

      <StoreBanner products={products} userName={userName} loading={loading} />

      {!loading && products.length > 0 && (
        <div style={{ marginBottom: 28 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
            <div>
              <h3 style={{ fontSize: 16, fontWeight: 800, color: '#1C1C1A', margin: 0, letterSpacing: '-0.01em' }}>Productos destacados</h3>
              <p style={{ fontSize: 12, color: '#737370', margin: '2px 0 0' }}>Los más populares de nuestra tienda</p>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 14, overflowX: 'auto', paddingBottom: 8, scrollbarWidth: 'none' as const, msOverflowStyle: 'none' as const }}>
            {products.slice(0, 8).map(product => {
              const fav = isFavorite(product.id);
              const cs = getCategoryStyle(product.category);
              return (
                <div key={product.id}
                  onClick={() => { setSelectedProduct(product); setIsProductModalOpen(true); }}
                  style={{ minWidth: 180, maxWidth: 180, borderRadius: 18, border: '1px solid #EBEBEA', backgroundColor: 'white', overflow: 'hidden', cursor: 'pointer', flexShrink: 0, transition: 'transform 0.18s, box-shadow 0.18s', boxShadow: '0 2px 8px rgba(0,0,0,0.06)' }}
                  onMouseEnter={e => { const el = e.currentTarget as HTMLDivElement; el.style.transform = 'translateY(-4px)'; el.style.boxShadow = '0 12px 32px rgba(0,0,0,0.12)'; }}
                  onMouseLeave={e => { const el = e.currentTarget as HTMLDivElement; el.style.transform = 'translateY(0)'; el.style.boxShadow = '0 2px 8px rgba(0,0,0,0.06)'; }}>
                  <div style={{ position: 'relative', height: 150, backgroundColor: cs.bg, overflow: 'hidden' }}>
                    {product.image ? (
                      <img src={product.image} alt={product.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                        onError={e => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                    ) : (
                      <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <Leaf style={{ width: 32, height: 32, color: cs.color, opacity: 0.5 }} />
                      </div>
                    )}
                    <div style={{ position: 'absolute', bottom: 8, left: 8, backgroundColor: 'rgba(255,255,255,0.92)', borderRadius: 8, padding: '3px 8px' }}>
                      <span style={{ fontSize: 12, fontWeight: 800, color: '#1C1C1A' }}>{fmt(product.price)}</span>
                    </div>
                    <button onClick={e => { e.stopPropagation(); toggleFavorite({ id: String(product.id), name: product.name, price: product.price, image: product.image || '', category: product.category, stock: product.stock, description: product.description }); toast.success(fav ? 'Eliminado de favoritos' : 'Guardado en favoritos'); }}
                      style={{ position: 'absolute', top: 8, right: 8, width: 28, height: 28, borderRadius: '50%', backgroundColor: 'rgba(255,255,255,0.9)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 1px 4px rgba(0,0,0,0.12)' }}>
                      <Heart style={{ width: 13, height: 13, fill: fav ? '#EF4444' : 'none', color: fav ? '#EF4444' : '#9CA3AF' }} />
                    </button>
                  </div>
                  <div style={{ padding: '12px 12px 14px' }}>
                    <p style={{ fontSize: 12, fontWeight: 700, color: '#1C1C1A', margin: '0 0 2px', lineHeight: 1.3, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' as const, overflow: 'hidden' }}>{product.name}</p>
                    <p style={{ fontSize: 10, color: cs.color, margin: '0 0 10px', fontWeight: 600 }}>{product.category}</p>
                    <button onClick={e => { e.stopPropagation(); onAddToCart(product); }} disabled={product.stock === 0}
                      style={{ width: '100%', height: 34, borderRadius: 10, background: product.stock === 0 ? '#F3F4F6' : 'linear-gradient(135deg, #2D6A4F, #3A7D44)', color: product.stock === 0 ? '#9CA3AF' : 'white', fontSize: 11, fontWeight: 700, border: 'none', cursor: product.stock === 0 ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 5 }}>
                      {product.stock === 0 ? 'Agotado' : <><ShoppingCart style={{ width: 11, height: 11 }} /> Agregar</>}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap' as const, alignItems: 'center' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: 200 }}>
          <Search style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', width: 15, height: 15, color: '#9CA3AF', pointerEvents: 'none' as const }} />
          <input placeholder="Buscar productos..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
            style={{ width: '100%', paddingLeft: 38, paddingRight: 14, height: 42, borderRadius: 12, border: '1.5px solid #E5E5E2', backgroundColor: 'white', fontSize: 13, color: '#1C1C1A', outline: 'none', boxSizing: 'border-box' as const }} />
        </div>
        <button onClick={fetchProducts} disabled={loading}
          style={{ height: 42, padding: '0 16px', borderRadius: 12, border: '1.5px solid #E5E5E2', backgroundColor: 'white', fontSize: 12, color: '#737370', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
          <Repeat style={{ width: 13, height: 13 }} /> Actualizar
        </button>
      </div>

      <div style={{ display: 'flex', gap: 24, alignItems: 'flex-start' }}>

        <div style={{ width: 200, flexShrink: 0, position: 'sticky', top: 80 }}>
          <div style={{ backgroundColor: 'white', borderRadius: 20, border: '1px solid #EBEBEA', overflow: 'hidden', boxShadow: '0 4px 20px rgba(0,0,0,0.08)' }}>
            <div style={{ padding: '16px 18px 12px', background: 'linear-gradient(135deg, #1B4332, #3A7D44)', position: 'relative', overflow: 'hidden' }}>
              <div style={{ position: 'absolute', top: -15, right: -15, width: 70, height: 70, borderRadius: '50%', backgroundColor: 'rgba(255,255,255,0.07)' }} />
              <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                <div style={{ width: 30, height: 30, borderRadius: 9, backgroundColor: 'rgba(255,255,255,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Leaf style={{ width: 15, height: 15, color: '#86EFAC' }} />
                </div>
                <p style={{ fontSize: 12, fontWeight: 700, color: 'rgba(255,255,255,0.95)', textTransform: 'uppercase' as const, letterSpacing: '0.07em', margin: 0 }}>Categorías</p>
              </div>
            </div>
            <div style={{ padding: '10px 10px' }}>
              <button onClick={() => setCategoryFilter('all')} style={{ width: '100%', textAlign: 'left', padding: '10px 12px', border: 'none', cursor: 'pointer', borderRadius: 12, marginBottom: 3, fontSize: 13, fontWeight: categoryFilter === 'all' ? 700 : 500, backgroundColor: categoryFilter === 'all' ? '#F0FDF4' : 'transparent', color: categoryFilter === 'all' ? '#166534' : '#4B5563', display: 'flex', alignItems: 'center', justifyContent: 'space-between', boxShadow: categoryFilter === 'all' ? '0 2px 8px rgba(22,101,52,0.1)' : 'none' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
                  <div style={{ width: 30, height: 30, borderRadius: 9, backgroundColor: categoryFilter === 'all' ? '#DCFCE7' : '#F9FAFB', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                    <Package style={{ width: 14, height: 14, color: categoryFilter === 'all' ? '#16A34A' : '#9CA3AF' }} />
                  </div>
                  <span>Todas</span>
                </div>
                <span style={{ fontSize: 11, color: categoryFilter === 'all' ? '#16A34A' : '#9CA3AF', backgroundColor: categoryFilter === 'all' ? '#DCFCE7' : '#F3F4F6', borderRadius: 99, padding: '2px 9px', fontWeight: 700 }}>{products.length}</span>
              </button>
              <div style={{ height: 1, backgroundColor: '#F3F4F6', margin: '6px 4px 8px' }} />
              {categories.filter(c => c !== 'all').map(cat => {
                const count = products.filter(p => p.category === cat).length;
                const isActive = categoryFilter === cat;
                const cs = getCategoryStyle(cat);
                return (
                  <button key={cat} onClick={() => setCategoryFilter(cat)} style={{ width: '100%', textAlign: 'left', padding: '9px 12px', border: 'none', cursor: 'pointer', borderRadius: 12, marginBottom: 2, fontSize: 12.5, fontWeight: isActive ? 700 : 400, backgroundColor: isActive ? cs.bg : 'transparent', color: isActive ? cs.color : '#4B5563', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, boxShadow: isActive ? `0 2px 8px ${cs.color}18` : 'none' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 9, minWidth: 0 }}>
                      <div style={{ width: 30, height: 30, borderRadius: 9, backgroundColor: isActive ? `${cs.color}20` : '#F9FAFB', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                        <div style={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: cs.color, boxShadow: isActive ? `0 0 0 3px ${cs.color}30` : 'none' }} />
                      </div>
                      <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' as const }}>{cat}</span>
                    </div>
                    <span style={{ fontSize: 11, color: isActive ? cs.color : '#9CA3AF', backgroundColor: isActive ? `${cs.color}20` : '#F3F4F6', borderRadius: 99, padding: '2px 9px', fontWeight: 700, flexShrink: 0 }}>{count}</span>
                  </button>
                );
              })}
            </div>
          </div>
          {(searchTerm || categoryFilter !== 'all') && (
            <button onClick={() => { setSearchTerm(''); setCategoryFilter('all'); }} style={{ marginTop: 10, width: '100%', padding: '9px 0', borderRadius: 12, border: '1.5px solid #E5E5E2', backgroundColor: 'white', fontSize: 12, color: '#6B7280', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, fontWeight: 500 }}>
              ✕ Limpiar filtros
            </button>
          )}
        </div>

        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontSize: 13, color: '#737370', fontWeight: 500, marginBottom: 16 }}>
            {loading ? 'Cargando...' : `${filtered.length} producto${filtered.length !== 1 ? 's' : ''}${categoryFilter !== 'all' ? ` en "${categoryFilter}"` : ''}`}
          </p>

      {loading ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 18 }}>
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} style={{ borderRadius: 16, border: '1px solid #E5E5E2', backgroundColor: 'white', overflow: 'hidden' }}>
              <div style={{ height: 160, backgroundColor: '#F4F4F2' }} />
              <div style={{ padding: 14, display: 'flex', flexDirection: 'column' as const, gap: 8 }}>
                <div style={{ height: 14, backgroundColor: '#F4F4F2', borderRadius: 6, width: '70%' }} />
                <div style={{ height: 36, backgroundColor: '#F4F4F2', borderRadius: 8 }} />
              </div>
            </div>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div style={{ display: 'flex', flexDirection: 'column' as const, alignItems: 'center', justifyContent: 'center', padding: '80px 24px', color: '#9CA3AF' }}>
          <Package style={{ width: 48, height: 48, opacity: 0.2, marginBottom: 12 }} />
          <p style={{ fontSize: 15, fontWeight: 600, color: '#6B7280', marginBottom: 4 }}>Sin resultados</p>
          <p style={{ fontSize: 13 }}>Intenta con otros filtros</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 18, maxWidth: 720, margin: '0 auto' }}>
          {filtered.map(product => {
            const fav = isFavorite(product.id);
            const cs = getCategoryStyle(product.category);
            return (
              <div key={product.id}
                onClick={() => { setSelectedProduct(product); setIsProductModalOpen(true); }}
                style={{ borderRadius: 20, border: '1px solid #EBEBEA', backgroundColor: 'white', overflow: 'hidden', cursor: 'pointer', transition: 'transform 0.2s, box-shadow 0.2s', boxShadow: '0 2px 8px rgba(0,0,0,0.05)' }}
                onMouseEnter={e => { const el = e.currentTarget as HTMLDivElement; el.style.transform = 'translateY(-6px)'; el.style.boxShadow = '0 16px 40px rgba(0,0,0,0.12)'; }}
                onMouseLeave={e => { const el = e.currentTarget as HTMLDivElement; el.style.transform = 'translateY(0)'; el.style.boxShadow = '0 2px 8px rgba(0,0,0,0.05)'; }}
              >
                <div style={{ position: 'relative', height: 160, backgroundColor: cs.bg, overflow: 'hidden' }}>
                  {product.image ? (
                    <img
                      src={product.image}
                      alt={product.name}
                      style={{ width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.3s ease' }}
                      onError={e => { (e.target as HTMLImageElement).style.display = 'none'; (e.target as HTMLImageElement).nextElementSibling && ((e.target as HTMLImageElement).nextElementSibling as HTMLElement).style.setProperty('display', 'flex'); }}
                    />
                  ) : null}
                  <div style={{ position: product.image ? 'absolute' : 'relative', inset: 0, display: product.image ? 'none' : 'flex', flexDirection: 'column' as const, alignItems: 'center', justifyContent: 'center', gap: 8 }}>
                    <div style={{ width: 52, height: 52, borderRadius: 16, backgroundColor: 'rgba(255,255,255,0.75)', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 2px 8px rgba(0,0,0,0.08)' }}>
                      <Leaf style={{ width: 26, height: 26, color: cs.color }} />
                    </div>
                    <span style={{ fontSize: 11, fontWeight: 600, color: cs.color, opacity: 0.85 }}>{product.category}</span>
                  </div>
                  <div style={{ position: 'absolute', bottom: 10, right: 10, backgroundColor: 'rgba(255,255,255,0.92)', borderRadius: 8, padding: '4px 10px', boxShadow: '0 1px 4px rgba(0,0,0,0.1)' }}>
                    <span style={{ fontSize: 13, fontWeight: 800, color: '#1C1C1A' }}>{fmt(product.price)}</span>
                  </div>
                  {product.stock < 10 && (
                    <div style={{ position: 'absolute', top: 10, left: 10 }}>
                      <span style={{ backgroundColor: '#EF4444', color: 'white', fontSize: 10, fontWeight: 700, padding: '3px 8px', borderRadius: 99 }}>¡{product.stock} restantes!</span>
                    </div>
                  )}
                  <button onClick={e => { e.stopPropagation(); toggleFavorite({ id: String(product.id), name: product.name, price: product.price, image: product.image || '', category: product.category, stock: product.stock, description: product.description }); toast.success(fav ? 'Eliminado de favoritos' : 'Guardado en favoritos'); }}
                    style={{ position: 'absolute', top: 10, right: 10, width: 30, height: 30, borderRadius: '50%', backgroundColor: 'rgba(255,255,255,0.9)', border: 'none', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 1px 4px rgba(0,0,0,0.12)' }}>
                    <Heart style={{ width: 14, height: 14, fill: fav ? '#EF4444' : 'none', color: fav ? '#EF4444' : '#9CA3AF' }} />
                  </button>
                </div>
                <div style={{ padding: '14px 14px 16px' }}>
                  <p style={{ fontSize: 13, fontWeight: 600, color: '#1C1C1A', lineHeight: 1.4, marginBottom: 6, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' as const, overflow: 'hidden' }}>
                    {product.name}
                  </p>
                  {product.description && (
                    <p style={{ fontSize: 11, color: '#9CA3AF', lineHeight: 1.4, marginBottom: 10, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' as const, overflow: 'hidden' }}>
                      {product.description}
                    </p>
                  )}
                  <button onClick={e => { e.stopPropagation(); onAddToCart(product); }} disabled={product.stock === 0}
                    style={{ width: '100%', height: 40, borderRadius: 12, background: product.stock === 0 ? '#F3F4F6' : 'linear-gradient(135deg, #2D6A4F, #3A7D44)', color: product.stock === 0 ? '#9CA3AF' : 'white', fontSize: 12, fontWeight: 700, border: 'none', cursor: product.stock === 0 ? 'not-allowed' : 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 7, boxShadow: product.stock === 0 ? 'none' : '0 4px 12px rgba(58,125,68,0.3)', transition: 'all 0.15s' }}
                    onMouseEnter={e => { if (product.stock > 0) { (e.currentTarget as HTMLButtonElement).style.background = 'linear-gradient(135deg, #1B4332, #2D6A4F)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 6px 16px rgba(58,125,68,0.4)'; } }}
                    onMouseLeave={e => { if (product.stock > 0) { (e.currentTarget as HTMLButtonElement).style.background = 'linear-gradient(135deg, #2D6A4F, #3A7D44)'; (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 4px 12px rgba(58,125,68,0.3)'; } }}>
                    {product.stock === 0 ? <><Package style={{ width: 13, height: 13 }} /> Agotado</> : <><ShoppingCart style={{ width: 13, height: 13 }} /> Agregar al carrito</>}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <ProductDetailModal product={selectedProduct} isOpen={isProductModalOpen}
        onClose={() => { setIsProductModalOpen(false); setSelectedProduct(null); }}
        onAddToCart={onAddToCart} isFavorite={isFavorite}
        onToggleFavorite={p => toggleFavorite({ id: String(p.id), name: p.name, price: p.price, image: p.image || '', category: p.category, stock: p.stock, description: p.description })} />
        </div> 
      </div> 
    </div>
  );
}
